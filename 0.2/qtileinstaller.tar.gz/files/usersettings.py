# Modificator (mod4 = left winkey)
mod 		= "mod4"	

#Panel
panelsize	= 32		# Panelsize (px)
fontsizing	= 12		# Fontsize
defaultfont = 'sans'	# Font (must be installed though)

# Farben
fgcolor 	= "#49a1b5" # Iconcolors
bgcolor 	= "#424242" # Panelcolor

# Icons from Awesomefonts [sudo zypper in fontawesome-fonts])
icon_web 	= ""
icon_games 	= "" 
icon_window = ""
icon_edit 	= ""
icon_term 	= ""
icon_vol	= "Vol:"
icon_tray	= "Tray:"
icon_time	= "Time:"
icon_cpu	= "CPU:"
icon_quit	= "|"

# Icons für Groups
icon_gr1	= icon_web
icon_gr2	= icon_games
icon_gr3	= icon_window
icon_gr4	= icon_edit
icon_gr5	= icon_term

# Wallpaper
wallpaper_img	= "~/.config/qtile/qtile.png"
wallpaper_set	= "fill"


'''Quick and dirty Qtile tutorial:
Mod Key + 1			= Switch to first group
Mod Key + 2			= Switch to second group
... and so on

Mod Key + r			= command prompt (spawn) -> enter a programname and it will open up (e.g. firefox)
Mod Key + Return	= will open a Terminal
Mod Key + TAB		= switch between layout modes (Full Screen or columns)
Mod Key + Spacebar	= switch between Windows (usefull when in fullscreen layout)


Mod Key + Shift + 1	= Move active window to group 1
Mod Key + Shift + 2	= Move active window to group 2
... and so on

That should kickstart your qtile experience. 
Have Fun'''
