#!/bin/sh
nm-applet &
compton &
